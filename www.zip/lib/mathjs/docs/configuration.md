# Configuration

This page has been moved [here](core/configuration.md).
