# Serialization

This page has been moved [here](core/serialization.md).
